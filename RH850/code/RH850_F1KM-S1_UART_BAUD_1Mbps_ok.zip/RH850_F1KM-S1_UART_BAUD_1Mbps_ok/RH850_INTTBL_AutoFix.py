'''
自動修正RH850的中斷向量表
* 選擇 RH850 家族 F1KM-S1 或 F1KM-S4
* (由 SmartConfigurator目錄)複製 intprg 檔案
* 新增 intprg 檔案至專案
* 新增現有路徑至 include 搜尋路徑
* 修改 boot.asm
    - 修改為使用 TABLE REFERENCE 方法
    - 指定中斷向量表 section
'''
import sys
import os
import re
from pathlib import Path
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font
from openpyxl.styles import Color
import xml.etree.ElementTree as ET
import shutil
import uuid

# User settings
KEY_INTPRG_C = 'sc_intprg-S1.c'
KEY_TAR_PATH = r'C:\Program Files (x86)\Renesas Electronics\SmartConfigurator\RH850\RH850F1KM_SampleProjects\intprg'

# advanced settings
get_path = lambda x: '\\'.join(x.split("\\")[:-1])      # C:\folder
get_path_name  = lambda x:os.path.splitext(x)[0]        # C:\folder\filename
get_name  = lambda x:get_path_name(x).split("\\")[-1]   # filename
get_ext  = lambda x:os.path.splitext(x)[1]              # .ext
show_path = lambda x: x if len(x)<30 else x[:10]+'...'+x[-15:]

ext_filters = ['.mtpj']

def get_files(cur_path, ext=''):
    if ext == '':
        ext = ext_filters
    out = []
    # 遍歷目錄下所有的檔案
    for dirPath, dirNames, fileNames in os.walk(cur_path):
        for f in fileNames:
            if cur_path == dirPath:
                if get_ext(f) in ext:
                    out.append(f)
    return out

def gen_output_filename(src_filename, prefix='', suffix='', ext=''):
    ''' 由輸入名產生輸出檔名 
            Usage: gen_output_filename('C:\\folder\\filename.ext', suffix='_p', ext='.out')
                   c:\folder\filenae_p.out
    '''
    full_path_name = src_filename
    full_path = "\\".join(full_path_name.split("\\")[:-1])
    filename = get_name(full_path_name)
    file_ext = get_ext(full_path_name)

    if ext == '':       # 沒有輸入時，使用原來的副檔名
        ext = file_ext
    elif ext == '.':    # 不使用副檔名
        ext = ''
    elif ext[0] != '.': # 輸入的副檔名不包含 '.' ，自動加上
        ext = '.' + ext

    if full_path == '':
        out_filename = prefix + filename + suffix + ext
    else:
        out_filename = full_path + "\\" + prefix + filename + suffix + ext

    return out_filename

#================================================================================
# 選擇 RH850 家族
#================================================================================
rh850_devices = ["RH850/F1KM-S1", "RH850/F1KM-S4"]
input_filename = ''
while input_filename == '':
    print()
    print("Please select your device:")
    for idx, file in enumerate(rh850_devices):
        print("{}. {}".format(idx+1, file))
    print("q. Exit")
    r = input("Select device:")
    if r.lower() == 'q':
        print("Exit!!!")
        exit()
    if int(r) >= 1 and int(r) <= len(rh850_devices):
        input_filename = rh850_devices[int(r)-1]

KEY_INTPRG_C = 'sc_intprg-S1.c' if int(r) == 1 else 'sc_intprg-S4.c'
print("KEY_INTPRG_C: {}".format(KEY_INTPRG_C))
#================================================================================
# 複製 intprg
#================================================================================
print('====================================================================================')
print('複製 {}:'.format(KEY_INTPRG_C))
src_path = KEY_TAR_PATH + '\\' + KEY_INTPRG_C
cur_path = get_path(sys.argv[0])
cur_path = cur_path + '\\' + KEY_INTPRG_C
r1 = os.path.isfile(cur_path)
if r1:
    print("  ==> 檔案已存在")
else:
    print("  ==> 檔案不存在")
    r = os.path.isfile(src_path)
    if r:
        print("  ==> 找到檔案 {}".format(show_path(src_path)))
        shutil.copyfile(src_path, cur_path)
        print("  ==> 複製檔案")
        print("    ==> From: {}".format(show_path(src_path)))
        print("    ==> To:   {}".format(show_path(cur_path)))
    else:
        print("  ==> 找不到檔案")

#================================================================================
# 新增 intprg 至專案
#================================================================================
cur_path = get_path(sys.argv[0])
files = get_files(cur_path, '.mtpj')
print('====================================================================================')
src_filename = files[0]
print("src_filename: {}".format(src_filename))
print('新增 {} 至專案：'.format(KEY_INTPRG_C))
lines = open(src_filename, 'r', encoding='utf-8').readlines()
# 檢查 intprg 檔案是否已存在
flg_intprg_exist = False
for l in lines:
    if KEY_INTPRG_C in l:
        flg_intprg_exist = True
        break

# intprg 檔案不存在，修改 mtpg 專案 
if flg_intprg_exist == False:
    out_lines = []
    flg_chk = False
    for idx, l in enumerate(lines):
        if 'Smart Configurator' in l:
            # 將 Instance 加在 Smart Configurator 後面
            flg_chk = True
        if flg_chk == True and '<ParentItem>' in l:
            # 儲存 SSmart Configurator 的 ParentItem
            str_parent = l
        if flg_chk == True and '</Instance>' in l:
            out_lines.append(l)
            out_lines.append('    <Instance Guid="{}">\n'.format(str(uuid.uuid4())))
            out_lines.append('      <Name>sc_intprg-S1.c</Name>\n')
            out_lines.append('      <Type>File</Type>\n')
            out_lines.append('      <RelativePath>' + KEY_INTPRG_C + '</RelativePath>\n')
            # out_lines.append('  <TreeImageGuid>941832c1-fc3b-4e1b-94e8-01ea17128b42</TreeImageGuid>')
            out_lines.append(str_parent)
            out_lines.append('    </Instance>\n')
            flg_chk = False
        else:
            out_lines.append(l)
    open(src_filename,'w', encoding='utf-8').writelines(out_lines)
else:
    print("  ==> 檔案 {} 已存在".format(KEY_INTPRG_C))
#================================================================================
# 新增現有路徑至 include 搜尋路徑
#================================================================================
print('====================================================================================')
# files = get_files(cur_path, '.mtpj')
# src_filename = files[0]
print('新增 local 路徑：{}'.format(src_filename))
mytree = ET.parse(src_filename)
myroot = mytree.getroot()
for x in myroot.findall('Class'):
    for i in x.findall('Instance'):
        t = i.find('COptionI-0')
        if t != None:
            tmp = t.text
            if tmp != None:
                print("  找到 include path, id={}".format(i.get('Guid')))
                l = tmp.split('\n')
                if '.' not in l:
                    t.text = t.text + '.\n'
                    print("    ==> 加上路徑 .")
                else:
                    print("    ==> 路徑已存在")
        t = i.find('LinkOptionStart-0')
        if t != None:
            tmp = t.text
            if tmp != None:
                print("  找到 Section 設定, id={}".format(i.get('Guid')))
                if 'EIINTTBL.const' not in l:
                    t.text = tmp.replace('EIINTTBL', 'EIINTTBL,EIINTTBL.const') + '\n'
                    print("    ==> EIINTTBL.const")
                else:
                    print("    ==> Section 已存在")

mytree.write(src_filename)
#================================================================================
# 修改 boot.asm
#================================================================================
files = get_files(cur_path, '.asm')
print('====================================================================================')
src_filename = files[0]
print('修改 boot.asm: {}'.format(src_filename))
lines = open(src_filename, 'r').readlines()
target_data = [ '.dw #_Dummy_EI ; INT0',
                '.dw #_Dummy_EI ; INT1',
                '.dw #_Dummy_EI ; INT2',
                '.rept 512 - 3',
                '.dw #_Dummy_EI ; INTn',
                '.endm'
]
out_lines = []
for idx, l in enumerate(lines):
    # 使用 TABLE REFERENCE
    if ';USE_TABLE_REFERENCE_METHOD .set 1' in l:
        l = l.replace(';USE','USE')
        print("    ==> {}".format(l.strip()))

    if 'mov #__sEIINTTBL, r6' in l.replace('\t', ' '):
        l = l.replace('EIINTTBL','EIINTTBL.const')
        print("    ==> {}".format(l.strip()))

    if '.section "EIINTTBL", const' in l:
        idx_bk = idx

    out_lines.append(l)

for i in range(len(target_data)):
    str_ori = out_lines[idx_bk + 2 + i]
    tmp = str_ori.strip().replace('\t', ' ')
    if tmp in target_data:
        str_new = str_ori.replace('.', ';.')
        out_lines[idx_bk + 2 + i] = str_new
        print("    ==> {}".format(str_new.strip()))

open(src_filename,'w').writelines(out_lines)

os.system('pause')