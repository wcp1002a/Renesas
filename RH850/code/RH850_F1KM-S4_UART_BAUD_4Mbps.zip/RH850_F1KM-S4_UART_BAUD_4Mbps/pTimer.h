#ifndef P_TIMER_H
#define P_TIMER_H
#include "r_cg_macrodriver.h"

#define P_1MS_COUNTER p1msCnt

extern uint32_t P_1MS_COUNTER;

void pTimerStart(uint32_t *tm);
uint32_t pTimerPass(uint32_t tm);
void pDelayMs(uint32_t delay_ms);

#endif /* P_TIMER_H */