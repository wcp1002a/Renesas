#include "r_cg_macrodriver.h"
#include "pTimer.h"

void pTimerStart(uint32_t *tm){
    *tm = P_1MS_COUNTER;
}

uint32_t pTimerPass(uint32_t tm){
    if(P_1MS_COUNTER >= tm){
        return (P_1MS_COUNTER - tm);
    }else{
        return (0xFFFFFFFF - tm + P_1MS_COUNTER + 1);
    }
}

void pDelayMs(uint32_t delay_ms){
    uint32_t tm;

    pTimerStart(&tm);
    while(pTimerPass(tm)<=delay_ms);
}